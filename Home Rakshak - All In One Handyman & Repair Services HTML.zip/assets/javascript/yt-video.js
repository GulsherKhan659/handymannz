/*-------------------------------------  Video Play Button -------------------------------------*/
$(document).ready(function () {
    $('.youtube').magnificPopup({
        items: {
            src: 'https://www.youtube.com/watch?v=FL9VJg_CpYc'
        },
        type: 'iframe'
    });
});